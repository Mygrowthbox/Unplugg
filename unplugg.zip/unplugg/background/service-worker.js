/**
 * UNPLUGG — service-worker.js
 * Tracker de temps (anti-idle), badge icône, reset minuit
 * Manifest V3 — Service Worker
 */

'use strict';

const SITES    = ['facebook', 'instagram', 'linkedin', 'youtube'];
const TICK_SEC = 1;

let activeTimers = {};

// ── Helpers ──────────────────────────────────────────────────────────────────

function getDateKey(offsetDays = 0) {
  const d = new Date();
  d.setDate(d.getDate() + offsetDays);
  return d.toISOString().slice(0, 10);
}

async function getTimeData() {
  const r = await chrome.storage.local.get('timeData');
  return r.timeData || {};
}

async function saveTimeData(timeData) {
  await chrome.storage.local.set({ timeData });
}

async function getSettings() {
  const r = await chrome.storage.local.get('settings');
  return r.settings || {};
}

function formatBadge(totalSeconds) {
  if (!totalSeconds || totalSeconds < 60) return '';
  const h = Math.floor(totalSeconds / 3600);
  const m = Math.floor((totalSeconds % 3600) / 60);
  return h > 0 ? `${h}h` : `${m}m`;
}

async function updateBadge() {
  const timeData = await getTimeData();
  const today    = timeData[getDateKey()] || {};
  const total    = SITES.reduce((sum, s) => sum + (today[s] || 0), 0);
  chrome.action.setBadgeText({ text: formatBadge(total) });
  chrome.action.setBadgeBackgroundColor({ color: '#7c6af7' });
}

async function isPaused() {
  const settings = await getSettings();
  return !!(settings.pauseUntil && Date.now() < settings.pauseUntil);
}

// ── Gestion du compteur ───────────────────────────────────────────────────────

function startCounter(tabId, site) {
  if (activeTimers[tabId]) return;

  const intervalId = setInterval(async () => {
    const tabs     = await chrome.tabs.query({ active: true, currentWindow: true });
    const isActive = tabs.some(t => t.id === tabId);
    if (!isActive)          { stopCounter(tabId); return; }
    if (await isPaused())   { stopCounter(tabId); return; }

    const timeData = await getTimeData();
    const dateKey  = getDateKey();
    if (!timeData[dateKey])        timeData[dateKey] = {};
    if (!timeData[dateKey][site])  timeData[dateKey][site] = 0;
    timeData[dateKey][site] += TICK_SEC;

    // Garder 30 jours max
    const keys = Object.keys(timeData).sort();
    if (keys.length > 30) delete timeData[keys[0]];

    await saveTimeData(timeData);
    await updateBadge();
  }, TICK_SEC * 1000);

  activeTimers[tabId] = { site, intervalId };
}

function stopCounter(tabId) {
  if (activeTimers[tabId]) {
    clearInterval(activeTimers[tabId].intervalId);
    delete activeTimers[tabId];
  }
}

function stopAllCounters() {
  Object.keys(activeTimers).forEach(id => stopCounter(Number(id)));
}

function siteFromUrl(url) {
  if (!url) return null;
  if (url.includes('facebook.com'))  return 'facebook';
  if (url.includes('instagram.com')) return 'instagram';
  if (url.includes('linkedin.com'))  return 'linkedin';
  if (url.includes('youtube.com'))   return 'youtube';
  return null;
}

// ── Messages depuis les content scripts ──────────────────────────────────────

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'ACTIVITY_PING') {
    const tabId = sender.tab?.id;
    const site  = message.site;
    if (tabId && site && !activeTimers[tabId]) {
      startCounter(tabId, site);
    }
    sendResponse({ ok: true });
  }

  if (message.type === 'ACTIVITY_STOP') {
    const tabId = sender.tab?.id;
    if (tabId) stopCounter(tabId);
    sendResponse({ ok: true });
  }

  if (message.type === 'PAUSE_UPDATED') {
    isPaused().then(paused => { if (paused) stopAllCounters(); });
    sendResponse({ ok: true });
  }

  return true;
});

// ── Événements des onglets ────────────────────────────────────────────────────

chrome.tabs.onActivated.addListener(() => {
  stopAllCounters();
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (changeInfo.status === 'loading') stopCounter(tabId);
});

chrome.tabs.onRemoved.addListener(tabId => {
  stopCounter(tabId);
});

// ── Alarm : reset à minuit ────────────────────────────────────────────────────

chrome.alarms.onAlarm.addListener(async alarm => {
  if (alarm.name === 'midnight-reset') {
    stopAllCounters();
    await updateBadge();
  }
});

function scheduleMidnightAlarm() {
  const now      = new Date();
  const midnight = new Date(now);
  midnight.setHours(24, 0, 0, 0);

  chrome.alarms.create('midnight-reset', {
    when:            midnight.getTime(),
    periodInMinutes: 24 * 60
  });
}

// ── Installation & démarrage ──────────────────────────────────────────────────

chrome.runtime.onInstalled.addListener(({ reason }) => {
  scheduleMidnightAlarm();
  updateBadge();
  if (reason === 'install') {
    console.log('[Unplugg] Extension installée.');
  }
});

chrome.runtime.onStartup.addListener(() => {
  scheduleMidnightAlarm();
  updateBadge();
});
