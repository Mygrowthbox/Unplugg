/**
 * UNPLUGG - fb-blocker.js
 *
 * Fonctionnalites actives (signaux stables uniquement) :
 *   - Reels       : [data-pagelet*="Reels"] ou aria-label="Reels"
 *   - Stories     : [data-pagelet="Stories|StoriesTray"] ou aria-label
 *   - Videos      : [data-pagelet*="Video"]
 *   - Groupes suggeres (sidebar) : [data-pagelet*="Group"] dans RightRail/LeftRail
 *
 * Fonctionnalites RETIREES (signaux instables, trop de faux positifs) :
 *   - Contenus sponsorises : Facebook obfusque "Sponsorisé" avec des classes
 *     CSS aléatoires qui changent régulièrement. Impossible à détecter
 *     de façon fiable sans bloquer des posts organiques.
 *   - Suggestions "Suivre" feed : la classe CSS du bouton n'est pas stable
 *     et apparait aussi dans des posts normaux.
 *
 * Ces choix préservent la conformité Chrome Web Store (pas de faux positifs,
 * pas de manipulation DOM agressive sur du contenu non ciblé).
 */

'use strict';

(function () {
  if (window.__unpluggFbInitialized) return;
  window.__unpluggFbInitialized = true;

  let settings = {
    enabled: true,
    reels: true,
    stories: true,
    videos: true,
    groupSuggestions: true
  };

  // ── Helpers ───────────────────────────────────────────────────────────────

  function hideElement(el, reason) {
    if (!el || el.dataset.unpluggHidden) return;
    el.dataset.unpluggHidden = reason;
    el.style.setProperty('display', 'none', 'important');
  }

  function showElement(el) {
    if (!el || !el.dataset.unpluggHidden) return;
    delete el.dataset.unpluggHidden;
    el.style.removeProperty('display');
  }

  function depthFromBody(el) {
    let d = 0, cur = el;
    while (cur && cur !== document.body) { d++; cur = cur.parentElement; }
    return d;
  }

  // ── STORIES ───────────────────────────────────────────────────────────────
  // Signal stable : data-pagelet="Stories" ou "StoriesTray" (attribut interne FB)

  function blockStories() {
    if (!settings.stories) return;
    [
      '[data-pagelet="Stories"]',
      '[data-pagelet="StoriesTray"]',
      '[aria-label="Stories"]',
      '[aria-label="Histoires"]'
    ].forEach(sel => {
      document.querySelectorAll(sel).forEach(el => {
        if (depthFromBody(el) >= 4) hideElement(el, 'stories');
      });
    });
  }

  // ── REELS ─────────────────────────────────────────────────────────────────
  // Signal stable : data-pagelet contenant "Reels"

  function blockReels() {
    if (!settings.reels) return;
    document.querySelectorAll('[data-pagelet*="Reels"], [aria-label="Reels"]').forEach(el => {
      if (depthFromBody(el) >= 4) hideElement(el, 'reels');
    });
  }

  // ── VIDEOS SUGGÉRÉES ──────────────────────────────────────────────────────
  // Signal stable : data-pagelet contenant "Video"

  function blockVideos() {
    if (!settings.videos) return;
    document.querySelectorAll('[data-pagelet*="Video"]').forEach(el => {
      if (depthFromBody(el) >= 4) hideElement(el, 'videos');
    });
  }

  // ── GROUPES SUGGÉRÉS (SIDEBAR) ────────────────────────────────────────────
  // Signal stable : sections des rails avec data-pagelet "Group"

  function blockSidebarSuggestions() {
    ['LeftRail', 'RightRail'].forEach(rail => {
      const container = document.querySelector(`[data-pagelet="${rail}"]`);
      if (!container) return;
      if (settings.groupSuggestions) {
        container.querySelectorAll('[data-pagelet*="Group"]')
          .forEach(el => hideElement(el, 'groupSuggestions'));
      }
    });
  }

  // ── SCAN ──────────────────────────────────────────────────────────────────

  function scanAll() {
    if (!settings.enabled) return;
    blockStories();
    blockReels();
    blockVideos();
    blockSidebarSuggestions();
  }

  function reEvaluateHidden() {
    document.querySelectorAll('[data-unplugg-hidden]').forEach(el => {
      const r = el.dataset.unpluggHidden;
      const shouldBlock = settings.enabled && (
        (r === 'stories'          && settings.stories) ||
        (r === 'reels'            && settings.reels) ||
        (r === 'videos'           && settings.videos) ||
        (r === 'groupSuggestions' && settings.groupSuggestions)
      );
      if (!shouldBlock) showElement(el);
    });
  }

  let scanTimeout = null;
  const observer = new MutationObserver(() => {
    clearTimeout(scanTimeout);
    scanTimeout = setTimeout(scanAll, 150);
  });
  observer.observe(document.body, { childList: true, subtree: true });

  async function loadSettings() {
    try {
      const result = await chrome.storage.local.get('settings');
      const s = result.settings?.facebook;
      if (s) settings = { ...settings, ...s };
    } catch (_) {}
    scanAll();
  }

  chrome.runtime.onMessage.addListener(message => {
    if (message.type === 'SETTINGS_UPDATED') {
      const s = message.settings?.facebook;
      if (s) settings = { ...settings, ...s };
      reEvaluateHidden();
      scanAll();
    }
  });

  loadSettings();

})();
