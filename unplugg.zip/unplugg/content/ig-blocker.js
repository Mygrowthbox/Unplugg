/**
 * UNPLUGG - ig-blocker.js
 *
 * STORIES (HTML reel confirme) :
 * Le conteneur stories est <div data-pagelet="story_tray">.
 * C'est un attribut data-pagelet exactement comme Facebook.
 * Stable et specifique — ne pas utiliser aria-label.
 *
 * SUGGESTIONS (HTML reel confirme) :
 * Span avec texte "Suggestions pour vous" / "Suggested for you"
 * dans un div cache (height:0, overflow:hidden, visibility:hidden).
 * On scanne uniquement le header de l'article (firstElementChild)
 * pour eviter les faux positifs sur le contenu du post.
 *
 * SCROLL INFINI :
 * On utilise visibility:hidden + height:0 au lieu de display:none
 * pour ne pas bloquer le mecanisme de scroll infini d'Instagram.
 *
 * POPIN CONSENTEMENT :
 * On attend la disparition du dialog RGPD avant de scanner.
 */

'use strict';

(function () {
  if (window.__unpluggIgInitialized) return;
  window.__unpluggIgInitialized = true;

  let settings = {
    enabled: true,
    reels: true,
    stories: true,
    sponsored: true,
    suggestions: true
  };
  let consentDismissed = false;

  const FOLLOW_TEXTS    = new Set(['suivre', 'follow']);
  const SUGGESTED_TEXTS = new Set([
    'suggestions pour vous',
    'suggested for you',
    'vorgeschlagen fur dich',
    'sugerido para ti',
    'suggerito per te',
    'sponsorise', 'sponsorisé',
    'sponsored'
  ]);

  // ── Helpers ───────────────────────────────────────────────────────────────

  // visibility:hidden + height:0 pour ne pas casser le scroll infini
  function hideElement(el, reason) {
    if (!el || el.dataset.unpluggHidden) return;
    el.dataset.unpluggHidden = reason;
    el.style.setProperty('visibility', 'hidden', 'important');
    el.style.setProperty('height', '0', 'important');
    el.style.setProperty('overflow', 'hidden', 'important');
    el.style.setProperty('min-height', '0', 'important');
    el.style.setProperty('padding', '0', 'important');
    el.style.setProperty('margin', '0', 'important');
  }

  function showElement(el) {
    if (!el || !el.dataset.unpluggHidden) return;
    delete el.dataset.unpluggHidden;
    ['visibility', 'height', 'overflow', 'min-height', 'padding', 'margin']
      .forEach(p => el.style.removeProperty(p));
  }

  // ── Popin consentement ────────────────────────────────────────────────────

  function isConsentPopinVisible() {
    const dialogs = document.querySelectorAll('[role="dialog"]');
    for (const d of dialogs) {
      const text = (d.textContent || '').toLowerCase();
      if (text.includes('cookie') || text.includes('consent') ||
          text.includes('accepter') || text.includes('accept') ||
          text.includes('autoriser') || text.includes('allow')) return true;
    }
    const btns = document.querySelectorAll('button');
    for (const b of btns) {
      const t = (b.textContent || '').trim().toLowerCase();
      if (t === 'tout accepter' || t === 'allow all cookies' || t === 'accept all') return true;
    }
    return false;
  }

  function waitForConsentDismissal() {
    if (consentDismissed) return;
    if (!isConsentPopinVisible()) {
      consentDismissed = true;
      setTimeout(scanAll, 600);
      return;
    }
    const obs = new MutationObserver(() => {
      if (!isConsentPopinVisible()) {
        consentDismissed = true;
        obs.disconnect();
        setTimeout(scanAll, 800);
      }
    });
    obs.observe(document.body, { childList: true, subtree: true });
    setTimeout(() => {
      if (!consentDismissed) {
        consentDismissed = true;
        obs.disconnect();
        scanAll();
      }
    }, 30000);
  }

  // ── Stories ───────────────────────────────────────────────────────────────

  function blockStoriesBar() {
    if (!settings.stories) return;

    // Signal principal : data-pagelet="story_tray" (confirme dans le HTML reel)
    const tray = document.querySelector('[data-pagelet="story_tray"]');
    if (tray) {
      hideElement(tray, 'stories');
      return;
    }

    // Fallback : aria-label (peut varier selon la langue)
    document.querySelectorAll('[aria-label="Stories"], [aria-label="Histoires"]').forEach(el => {
      if (!el.closest('article')) hideElement(el, 'stories');
    });
  }

  // ── Suggestions + Sponsored ───────────────────────────────────────────────

  function isSuggestionOrSponsored(article) {
    // Scanner uniquement le header (firstElementChild) de l'article
    // pour eviter les faux positifs sur le contenu du post
    const header = article.firstElementChild;
    if (!header) return false;

    // Signal A : texte "Suggestions pour vous" dans le header
    // Ce texte est dans un div cache (height:0) mais textContent le lit
    const headerText = (header.textContent || '').toLowerCase();
    for (const term of SUGGESTED_TEXTS) {
      if (headerText.includes(term)) return true;
    }

    // Signal B : bouton "Suivre"/"Follow" visible dans le header
    const buttons = header.querySelectorAll('[role="button"]');
    for (const btn of buttons) {
      const txt = (btn.textContent || '').trim().toLowerCase();
      if (FOLLOW_TEXTS.has(txt)) return true;
    }

    return false;
  }

  function blockSuggestionsAndSponsored() {
    if (!settings.sponsored && !settings.suggestions) return;
    document.querySelectorAll('article').forEach(article => {
      if (article.dataset.unpluggHidden) return;
      if (isSuggestionOrSponsored(article)) {
        hideElement(article, 'sponsored');
      }
    });
  }

  // ── Reels ─────────────────────────────────────────────────────────────────

  function blockReels() {
    if (!settings.reels) return;
    document.querySelectorAll('article').forEach(article => {
      if (article.dataset.unpluggHidden) return;
      if (article.querySelector('a[href*="/reels/"], a[href*="/reel/"]')) {
        hideElement(article, 'reels');
      }
    });
    document.querySelectorAll('[aria-label="Reels"], a[href="/reels/"]').forEach(el => {
      if (!el.closest('article')) hideElement(el.closest('li') || el, 'reels');
    });
  }

  // ── Scan ──────────────────────────────────────────────────────────────────

  function scanAll() {
    if (!consentDismissed || !settings.enabled) return;
    blockStoriesBar();
    blockReels();
    blockSuggestionsAndSponsored();
  }

  function reEvaluateHidden() {
    document.querySelectorAll('[data-unplugg-hidden]').forEach(el => {
      const r = el.dataset.unpluggHidden;
      const shouldBlock = settings.enabled && (
        (r === 'sponsored' && (settings.sponsored || settings.suggestions)) ||
        (r === 'stories'   && settings.stories) ||
        (r === 'reels'     && settings.reels)
      );
      if (!shouldBlock) showElement(el);
    });
  }

  let scanTimeout = null;
  const observer = new MutationObserver(() => {
    if (!consentDismissed) return;
    clearTimeout(scanTimeout);
    scanTimeout = setTimeout(scanAll, 250);
  });
  observer.observe(document.body, { childList: true, subtree: true });

  async function loadSettings() {
    try {
      const result = await chrome.storage.local.get('settings');
      const s = result.settings?.instagram;
      if (s) settings = { ...settings, ...s };
    } catch (_) {}
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', waitForConsentDismissal);
    } else {
      waitForConsentDismissal();
    }
  }

  chrome.runtime.onMessage.addListener(message => {
    if (message.type === 'SETTINGS_UPDATED') {
      const s = message.settings?.instagram;
      if (s) settings = { ...settings, ...s };
      reEvaluateHidden();
      if (consentDismissed) scanAll();
    }
  });

  loadSettings();

})();
