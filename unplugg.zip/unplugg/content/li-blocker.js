/**
 * UNPLUGG — li-blocker.js
 *
 * SIGNAUX ADS (basés sur HTML réel) :
 * A) <p>Promoted</p> ou <p>Sponsorisé</p> dans un lien /company/ (pub payante)
 * B) aria-label="View Sponsored Content" (image de pub)
 * C) data-view-name^="ad-"
 * D) utm_medium=paid + hsa_net=linkedin dans les URLs
 *
 * SIGNAUX SUGGESTED (basés sur HTML réel) :
 * LinkedIn marque les posts suggérés avec un <p>Suggested</p> ou <p>Suggéré</p>
 * dans un div header AVANT le lien de la company.
 * Ce <p> est dans un div avec une classe spécifique (pas dans un lien /company/).
 *
 * CONTENEUR DU POST : role="listitem" avec componentkey
 */

'use strict';

(function () {
  if (window.__unpluggLiInitialized) return;
  window.__unpluggLiInitialized = true;

  let settings = { enabled: true, ads: true, suggestedPosts: true };

  const PROMOTED_TEXTS   = new Set(['promoted', 'sponsorisé', 'sponsored']);
  const SUGGESTED_TEXTS  = new Set(['suggested', 'suggéré', 'suggeriert', 'sugerido', 'sugerowane']);

  // ── Helpers ───────────────────────────────────────────────────────────────

  function hideElement(el, reason) {
    if (!el || el.dataset.unpluggHidden) return;
    el.dataset.unpluggHidden = reason;
    el.style.setProperty('display', 'none', 'important');
  }

  function showElement(el) {
    if (!el || !el.dataset.unpluggHidden) return;
    delete el.dataset.unpluggHidden;
    el.style.removeProperty('display');
  }

  function getPostAncestor(el) {
    let current = el?.parentElement;
    let depth = 0;
    while (current && depth < 20) {
      if (current.getAttribute('role') === 'listitem') return current;
      if (
        current.dataset.urn ||
        current.classList.contains('feed-shared-update-v2') ||
        current.classList.contains('occludable-update')
      ) return current;
      if (
        current.tagName === 'LI' &&
        current.closest('[class*="scaffold-finite-scroll"]')
      ) return current;
      if (current.tagName === 'MAIN' || current.tagName === 'BODY') return null;
      current = current.parentElement;
      depth++;
    }
    return null;
  }

  // ── 1. ADS ────────────────────────────────────────────────────────────────

  function blockAds() {
    if (!settings.ads) return;

    // Méthode A : <p>Promoted</p> dans un lien /company/
    document.querySelectorAll('a[href*="/company/"]').forEach(link => {
      for (const p of link.querySelectorAll('p')) {
        const txt = (p.textContent || '').trim().toLowerCase();
        if (PROMOTED_TEXTS.has(txt)) {
          const ancestor = getPostAncestor(link);
          if (ancestor) hideElement(ancestor, 'ads');
          return;
        }
      }
    });

    // Méthode B : image marquée "View Sponsored Content"
    document.querySelectorAll('[aria-label="View Sponsored Content"]').forEach(el => {
      const ancestor = getPostAncestor(el);
      if (ancestor) hideElement(ancestor, 'ads');
    });

    // Méthode C : data-view-name contenant "ad-"
    document.querySelectorAll('[data-view-name^="ad-"]').forEach(el => {
      const ancestor = getPostAncestor(el);
      if (ancestor) hideElement(ancestor, 'ads');
    });

    // Méthode D : URL pub payante LinkedIn
    document.querySelectorAll('a[href*="hsa_net=linkedin"][href*="utm_medium=paid"]').forEach(el => {
      const ancestor = getPostAncestor(el);
      if (ancestor) hideElement(ancestor, 'ads');
    });
  }

  // ── 2. POSTS SUGGÉRÉS ─────────────────────────────────────────────────────

  function blockSuggestedPosts() {
    if (!settings.suggestedPosts) return;

    // Signal principal (HTML réel fourni) :
    // LinkedIn injecte un <p>Suggested</p> dans le header du post suggéré.
    // Ce <p> est dans un div qui contient aussi un bouton "Follow" et un bouton "Hide".
    // Il n'est PAS dans un lien /company/.
    document.querySelectorAll('p').forEach(p => {
      // Ignorer les <p> à l'intérieur des liens company (ce sont les pubs)
      if (p.closest('a[href*="/company/"]')) return;
      const txt = (p.textContent || '').trim().toLowerCase();
      if (SUGGESTED_TEXTS.has(txt)) {
        const ancestor = getPostAncestor(p);
        if (ancestor) hideElement(ancestor, 'suggestedPosts');
      }
    });

    // Fallback : data-view-name cohort
    document.querySelectorAll('[data-view-name*="cohort"]').forEach(el => {
      const ancestor = getPostAncestor(el);
      if (ancestor) hideElement(ancestor, 'suggestedPosts');
    });

    // Sections sidebar
    document.querySelectorAll('.scaffold-layout__aside section').forEach(section => {
      hideElement(section, 'suggestedPosts');
    });
  }

  // ── Scan complet ──────────────────────────────────────────────────────────

  function scanAll() {
    if (!settings.enabled) return;
    blockAds();
    blockSuggestedPosts();
  }

  function reEvaluateHidden() {
    document.querySelectorAll('[data-unplugg-hidden]').forEach(el => {
      const r = el.dataset.unpluggHidden;
      const shouldBlock = settings.enabled && (
        (r === 'ads'            && settings.ads) ||
        (r === 'suggestedPosts' && settings.suggestedPosts)
      );
      if (!shouldBlock) showElement(el);
    });
  }

  let scanTimeout = null;
  const observer = new MutationObserver(() => {
    clearTimeout(scanTimeout);
    scanTimeout = setTimeout(scanAll, 150);
  });
  observer.observe(document.body, { childList: true, subtree: true });

  async function loadSettings() {
    try {
      const result = await chrome.storage.local.get('settings');
      const s = result.settings?.linkedin;
      if (s) settings = { ...settings, ...s };
    } catch (_) {}
    scanAll();
  }

  chrome.runtime.onMessage.addListener(message => {
    if (message.type === 'SETTINGS_UPDATED') {
      const s = message.settings?.linkedin;
      if (s) settings = { ...settings, ...s };
      reEvaluateHidden();
      scanAll();
    }
  });

  loadSettings();

})();
