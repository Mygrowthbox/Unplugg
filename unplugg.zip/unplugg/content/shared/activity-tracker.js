/**
 * UNPLUGG — activity-tracker.js
 * Détecte l'activité utilisateur (scroll, clic) et envoie des pings
 * au service worker. Aucun contenu utilisateur n'est lu ou transmis.
 */

'use strict';

(function () {
  if (window.__unpluggTrackerInitialized) return;
  window.__unpluggTrackerInitialized = true;

  const ACTIVITY_TIMEOUT_MS = 60 * 1000;
  const PING_INTERVAL_MS    = 10 * 1000;

  let lastActivityTime = 0;

  function getSite() {
    const host = window.location.hostname;
    if (host.includes('facebook.com'))  return 'facebook';
    if (host.includes('instagram.com')) return 'instagram';
    if (host.includes('linkedin.com'))  return 'linkedin';
    if (host.includes('youtube.com'))   return 'youtube';
    return null;
  }

  const site = getSite();
  if (!site) return;

  function recordActivity() {
    lastActivityTime = Date.now();
  }

  document.addEventListener('scroll',    recordActivity, { passive: true, capture: true });
  document.addEventListener('click',     recordActivity, { passive: true, capture: true });
  document.addEventListener('keypress',  recordActivity, { passive: true, capture: true });
  document.addEventListener('touchstart',recordActivity, { passive: true, capture: true });

  async function sendPing() {
    const timeSinceAct = Date.now() - lastActivityTime;

    if (lastActivityTime === 0 || timeSinceAct > ACTIVITY_TIMEOUT_MS) {
      try { await chrome.runtime.sendMessage({ type: 'ACTIVITY_STOP' }); } catch (_) {}
      return;
    }

    try { await chrome.runtime.sendMessage({ type: 'ACTIVITY_PING', site }); } catch (_) {}
  }

  setInterval(sendPing, PING_INTERVAL_MS);
  recordActivity();

})();
