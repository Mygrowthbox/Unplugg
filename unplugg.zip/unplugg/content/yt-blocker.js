/**
 * UNPLUGG — yt-blocker.js
 * Bloque les contenus algorithmiques sur YouTube.
 * Lecture limitée aux attributs ARIA et libellés d'interface uniquement.
 */

'use strict';

(function () {
  if (window.__unpluggYtInitialized) return;
  window.__unpluggYtInitialized = true;

  const SHORTS_KEYWORDS = ['shorts', 'short'];

  let settings = { shortsFeed: true, shortsSidebar: true };

  function getSafeText(el) {
    const ariaLabel = (el.getAttribute('aria-label') || '').toLowerCase();
    if (ariaLabel) return ariaLabel;
    const title = el.querySelector('#title, .title, yt-formatted-string');
    return (title?.textContent || '').toLowerCase();
  }

  function containsKeyword(el, keywords) {
    return keywords.some(kw => getSafeText(el).includes(kw));
  }

  function isInSidebar(el) {
    return !!el.closest('ytd-guide-renderer, ytd-mini-guide-renderer, #guide, #mini-guide');
  }

  function hideElement(el, reason) {
    if (el.dataset.unpluggHidden) return;
    el.dataset.unpluggHidden = reason;
    el.style.display = 'none';
  }

  function showElement(el) {
    if (!el.dataset.unpluggHidden) return;
    delete el.dataset.unpluggHidden;
    el.style.display = '';
  }

  function scanElement(el) {
    if (!(el instanceof Element)) return;

    // Shorts sidebar
    if (settings.shortsSidebar && isInSidebar(el)) {
      if (containsKeyword(el, SHORTS_KEYWORDS)) { hideElement(el, 'shortsSidebar'); return; }
    }
    if (settings.shortsSidebar && el.matches('ytd-guide-entry-renderer, ytd-mini-guide-entry-renderer')) {
      if (el.querySelector('a[href*="/shorts"]')) { hideElement(el, 'shortsSidebar'); return; }
    }

    // Shorts feed
    if (settings.shortsFeed) {
      if (el.matches('ytd-rich-section-renderer, ytd-reel-shelf-renderer')) { hideElement(el, 'shortsFeed'); return; }
      if (!isInSidebar(el) && containsKeyword(el, SHORTS_KEYWORDS))         { hideElement(el, 'shortsFeed'); return; }
    }
  }

  function reEvaluateHidden() {
    document.querySelectorAll('[data-unplugg-hidden]').forEach(el => {
      const r = el.dataset.unpluggHidden;
      const shouldBlock = (
        (r === 'shortsFeed'    && settings.shortsFeed) ||
        (r === 'shortsSidebar' && settings.shortsSidebar)
      );
      if (!shouldBlock) showElement(el);
    });
  }

  function scanAll() {
    document.querySelectorAll(
      'ytd-rich-section-renderer, ytd-reel-shelf-renderer, ' +
      'ytd-guide-entry-renderer, ytd-mini-guide-entry-renderer, ' +
      'ytd-shelf-renderer'
    ).forEach(el => scanElement(el));
  }

  const observer = new MutationObserver(mutations => {
    mutations.forEach(mutation => {
      mutation.addedNodes.forEach(node => {
        if (node.nodeType === Node.ELEMENT_NODE) scanElement(node);
      });
    });
  });
  observer.observe(document.documentElement, { childList: true, subtree: true });

  async function loadSettings() {
    try {
      const result = await chrome.storage.local.get('settings');
      const s = result.settings?.youtube;
      if (s) settings = { ...settings, ...s };
    } catch (_) {}
    scanAll();
  }

  chrome.runtime.onMessage.addListener(message => {
    if (message.type === 'SETTINGS_UPDATED') {
      const s = message.settings?.youtube;
      if (s) settings = { ...settings, ...s };
      reEvaluateHidden();
      scanAll();
    }
  });

  loadSettings();

})();
