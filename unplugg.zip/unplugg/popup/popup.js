/**
 * UNPLUGG — popup.js
 * Gère : consentement, onglets, stats, toggles, langue dynamique, export
 * Zéro dépendance externe — Vanilla JS
 */

'use strict';

// ── Traductions embarquées ────────────────────────────────────────────────────
// Nécessaires pour le changement de langue dynamique sans rechargement de page.
// chrome.i18n.getMessage() utilise la locale Chrome, pas notre préférence stockée.

const TRANSLATIONS = {
  fr: {
    tabStats:              "Aujourd'hui",
    tabSettings:           "Paramètres",
    consentTitle:          "Bienvenue sur Unplugg",
    consentBody:           "Pour fonctionner, Unplugg analyse uniquement les libellés d'interface (boutons, titres de sections) sur Facebook, Instagram, LinkedIn et YouTube afin de masquer les contenus algorithmiques. Aucun message, post ou donnée personnelle n'est lu, capturé ou transmis. Toutes les données restent sur votre appareil.",
    consentAccept:         "J'accepte et j'active Unplugg",
    vsYesterday:           "vs hier",
    noDataYet:             "Aucune donnée pour aujourd'hui",
    facebook:              "Facebook",
    instagram:             "Instagram",
    linkedin:              "LinkedIn",
    youtube:               "YouTube",
    blockReels:            "Bloquer les Reels",
    blockStories:          "Bloquer les Stories (barre du haut)",
    blockSponsored:        "Bloquer les contenus sponsorisés",
    blockVideos:           "Bloquer les Vidéos suggérées",
    blockFollowSuggestions:"Bloquer les suggestions Suivre",
    blockGroupSuggestions: "Bloquer les groupes suggérés",
    blockSuggestions:      "Bloquer les suggestions",
    blockAds:              "Bloquer le contenu promu",
    blockSuggestedPosts:   "Bloquer les posts suggérés",
    blockShortsFeed:       "Bloquer les Shorts (feed)",
    blockShortsSidebar:    "Bloquer les Shorts (sidebar)",
    settingsLang:          "Langue",
    exportData:            "Exporter mes données (JSON)",
    exportDone:            "Fichier téléchargé ✓",
    minutes:               "min",
    hours:                 "h",
  },
  en: {
    tabStats:              "Today",
    tabSettings:           "Settings",
    consentTitle:          "Welcome to Unplugg",
    consentBody:           "To work, Unplugg only reads interface labels (buttons, section headings) on Facebook, Instagram, LinkedIn and YouTube to hide algorithmic content. No messages, posts or personal data are read, captured or transmitted. All data stays on your device.",
    consentAccept:         "I agree — Activate Unplugg",
    vsYesterday:           "vs yesterday",
    noDataYet:             "No data yet for today",
    facebook:              "Facebook",
    instagram:             "Instagram",
    linkedin:              "LinkedIn",
    youtube:               "YouTube",
    blockReels:            "Block Reels",
    blockStories:          "Block Stories (top bar)",
    blockSponsored:        "Block sponsored content",
    blockVideos:           "Block suggested Videos",
    blockFollowSuggestions:"Block Follow suggestions",
    blockGroupSuggestions: "Block suggested Groups",
    blockSuggestions:      "Block suggestions",
    blockAds:              "Block promoted content",
    blockSuggestedPosts:   "Block suggested posts",
    blockShortsFeed:       "Block Shorts (feed)",
    blockShortsSidebar:    "Block Shorts (sidebar)",
    settingsLang:          "Language",
    exportData:            "Export my data (JSON)",
    exportDone:            "File downloaded ✓",
    minutes:               "min",
    hours:                 "h",
  }
};

// Langue active courante
let currentLang = 'en';

function t(key) {
  return TRANSLATIONS[currentLang]?.[key] || TRANSLATIONS['en'][key] || key;
}

function applyI18n() {
  document.querySelectorAll('[data-i18n]').forEach(el => {
    el.textContent = t(el.getAttribute('data-i18n'));
  });
  const ts   = document.getElementById('tab-stats');
  const tset = document.getElementById('tab-settings');
  if (ts)   ts.textContent   = t('tabStats');
  if (tset) tset.textContent = t('tabSettings');
}

// ── Formatage du temps ──────────────────────────────────────────────────────

function formatTime(seconds) {
  if (!seconds || seconds < 60) return `0 ${t('minutes')}`;
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  if (h === 0) return `${m}${t('minutes')}`;
  return `${h}${t('hours')} ${m.toString().padStart(2, '0')}${t('minutes')}`;
}

function getDateKey(offsetDays = 0) {
  const d = new Date();
  d.setDate(d.getDate() + offsetDays);
  return d.toISOString().slice(0, 10);
}

// ── Rendu des stats ─────────────────────────────────────────────────────────

const SITES = ['facebook', 'instagram', 'linkedin', 'youtube'];

async function renderStats() {
  const todayKey     = getDateKey(0);
  const yesterdayKey = getDateKey(-1);

  const result   = await chrome.storage.local.get('timeData');
  const timeData = result.timeData || {};
  const today     = timeData[todayKey]     || {};
  const yesterday = timeData[yesterdayKey] || {};

  SITES.forEach(site => {
    const todaySec = today[site]     || 0;
    const yestSec  = yesterday[site] || 0;

    const timeEl = document.getElementById(`time-${site}`);
    if (timeEl) timeEl.textContent = formatTime(todaySec);

    const diffEl = document.getElementById(`diff-${site}`);
    if (diffEl) {
      if (yestSec === 0 && todaySec === 0) {
        diffEl.textContent = '';
        diffEl.className   = 'time-diff';
      } else {
        const delta = todaySec - yestSec;
        const sign  = delta >= 0 ? '+' : '−';
        diffEl.textContent = `${sign}${formatTime(Math.abs(delta))} ${t('vsYesterday')}`;
        diffEl.className   = `time-diff ${delta <= 0 ? 'better' : 'worse'}`;
      }
    }
  });
}

// ── Onglets ─────────────────────────────────────────────────────────────────

function initTabs() {
  document.querySelectorAll('.tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.tab').forEach(t => {
        t.classList.remove('active');
        t.setAttribute('aria-selected', 'false');
      });
      document.querySelectorAll('.panel').forEach(p => p.classList.add('hidden'));
      tab.classList.add('active');
      tab.setAttribute('aria-selected', 'true');
      const target = document.getElementById(tab.dataset.target);
      if (target) target.classList.remove('hidden');
    });
  });
}

// ── Toggles ─────────────────────────────────────────────────────────────────

async function renderToggles() {
  const result   = await chrome.storage.local.get('settings');
  const settings = result.settings || {};

  // Toggles des options individuelles
  document.querySelectorAll('.toggle-row input[type="checkbox"]').forEach(cb => {
    const siteSettings = settings[cb.dataset.site] || {};
    cb.checked = siteSettings[cb.dataset.key] !== undefined
      ? siteSettings[cb.dataset.key]
      : true;
  });

  // Toggles maitre (on/off par canal)
  document.querySelectorAll('.channel-toggle').forEach(cb => {
    const siteSettings = settings[cb.dataset.site] || {};
    // Par defaut : enabled = true
    cb.checked = siteSettings.enabled !== false;
    updatePlatformOptionsState(cb.dataset.site, cb.checked);
  });
}

function updatePlatformOptionsState(site, enabled) {
  const optionsList = document.querySelector(`.platform-options[data-platform="${site}"]`);
  if (optionsList) {
    optionsList.classList.toggle('disabled', !enabled);
  }
}

async function handleToggleChange(cb) {
  const result   = await chrome.storage.local.get('settings');
  const settings = result.settings || {};
  if (!settings[cb.dataset.site]) settings[cb.dataset.site] = {};
  settings[cb.dataset.site][cb.dataset.key] = cb.checked;
  await chrome.storage.local.set({ settings });

  // Si c'est le toggle maitre, mettre a jour l'apparence des options
  if (cb.classList.contains('channel-toggle')) {
    updatePlatformOptionsState(cb.dataset.site, cb.checked);
  }

  // Envoyer uniquement aux onglets des 4 plateformes concernees
  const SITE_URLS = [
    '*://*.facebook.com/*', '*://*.instagram.com/*',
    '*://*.linkedin.com/*', '*://*.youtube.com/*'
  ];
  chrome.tabs.query({ url: SITE_URLS }, tabs => {
    tabs.forEach(tab => {
      if (tab.id) {
        chrome.tabs.sendMessage(tab.id, { type: 'SETTINGS_UPDATED', settings })
          .catch(() => {});
      }
    });
  });
}

function initToggles() {
  // Options individuelles
  document.querySelectorAll('.toggle-row input[type="checkbox"]').forEach(cb => {
    cb.addEventListener('change', () => handleToggleChange(cb));
  });
  // Toggles maitres
  document.querySelectorAll('.channel-toggle').forEach(cb => {
    cb.addEventListener('change', () => handleToggleChange(cb));
  });
}

// ── Langue ──────────────────────────────────────────────────────────────────

async function renderLang() {
  document.querySelectorAll('.lang-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.lang === currentLang);
  });
}

function initLang() {
  document.querySelectorAll('.lang-btn').forEach(btn => {
    btn.addEventListener('click', async () => {
      currentLang = btn.dataset.lang;

      // Persistance
      const result   = await chrome.storage.local.get('settings');
      const settings = result.settings || {};
      settings.lang  = currentLang;
      await chrome.storage.local.set({ settings });

      // Tout retraduire immédiatement
      applyI18n();
      renderLang();
      await renderStats(); // Reformater les durées dans la bonne langue
    });
  });
}

// ── Export JSON ─────────────────────────────────────────────────────────────

async function exportData() {
  const result = await chrome.storage.local.get(['timeData', 'settings']);
  const blob   = new Blob([JSON.stringify(result, null, 2)], { type: 'application/json' });
  const url    = URL.createObjectURL(blob);
  const a      = document.createElement('a');
  a.href       = url;
  a.download   = `unplugg-export-${getDateKey()}.json`;
  a.click();
  URL.revokeObjectURL(url);

  const btn = document.getElementById('export-btn');
  btn.textContent = t('exportDone');
  setTimeout(() => { btn.textContent = t('exportData'); }, 3000);
}

function initExport() {
  document.getElementById('export-btn').addEventListener('click', exportData);
}

// ── Consentement ─────────────────────────────────────────────────────────────

async function checkConsent() {
  const result   = await chrome.storage.local.get('settings');
  const settings = result.settings || {};
  if (!settings.consentGiven) {
    showConsentScreen();
  } else {
    showMainScreen();
  }
}

function showConsentScreen() {
  document.getElementById('consent-screen').classList.remove('hidden');
  document.getElementById('main-screen').classList.add('hidden');

  document.getElementById('consent-title').textContent  = t('consentTitle');
  document.getElementById('consent-body').textContent   = t('consentBody');
  document.getElementById('consent-accept').textContent = t('consentAccept');

  document.getElementById('consent-accept').addEventListener('click', async () => {
    const result   = await chrome.storage.local.get('settings');
    const settings = result.settings || {};
    settings.consentGiven = true;
    settings.lang         = currentLang;
    settings.facebook  = { enabled: true, reels: true, stories: true, videos: true, groupSuggestions: true };
    settings.instagram = { enabled: true, reels: true, stories: true, sponsored: true, suggestions: true };
    settings.linkedin  = { enabled: true, ads: true, suggestedPosts: true };
    settings.youtube   = { enabled: true, shortsFeed: true, shortsSidebar: true };
    await chrome.storage.local.set({ settings });
    showMainScreen();
    await initMain();
  });
}

function showMainScreen() {
  document.getElementById('consent-screen').classList.add('hidden');
  document.getElementById('main-screen').classList.remove('hidden');
}

// ── Init principale ───────────────────────────────────────────────────────────

async function initMain() {
  applyI18n();
  await renderStats();
  await renderToggles();
  await renderLang();
  initTabs();
  initToggles();
  initLang();
  initExport();
}

// ── Bootstrap ─────────────────────────────────────────────────────────────────

document.addEventListener('DOMContentLoaded', async () => {
  // Langue : préférence stockée > langue du navigateur > 'en'
  const result      = await chrome.storage.local.get('settings');
  const settings    = result.settings || {};
  const browserLang = chrome.i18n.getUILanguage().slice(0, 2);
  currentLang = settings.lang || (TRANSLATIONS[browserLang] ? browserLang : 'en');

  applyI18n();
  await checkConsent();

  if (settings.consentGiven) {
    await initMain();
  }
});
